const express = require('express');
const path = require('path');
const app = express();
const port = process.env.PORT || 3000;

app.use(express.json());
app.use(express.static('public'));

let ubicaciones = [];

app.post('/guardar-ubicacion', (req, res) => {
  const { lat, lon, timestamp } = req.body;
  if (lat && lon) {
    ubicaciones.push({ lat, lon, timestamp });
    console.log('Ubicación recibida:', lat, lon);
    res.sendStatus(200);
  } else {
    res.sendStatus(400);
  }
});

app.get('/ubicaciones', (req, res) => {
  res.json(ubicaciones);
});

app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
